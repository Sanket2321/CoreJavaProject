package com.tka.client;

import java.util.ArrayList;

import com.tka.controller.ClassroomController;
import com.tka.entity.Classroom;

public class Client {
	public static void main(String args[])
	{
		  /*ArrayList<Classroom> arrayListcls=ClassroomDao.fetchAllClassrooms();
		  for(Classroom classroom:arrayListcls)
		  {
			  System.out.println(classroom);
		  }*/
		/*ArrayList<Classroom> arraylistcls=ClassroomController.fetchAllClassrooms();
		for (Classroom classroom : arraylistcls) {
		System.out.println(classroom);
		}*/
		Classroom classroom=ClassroomController.getsingleClassroomsDetailperID(101);
		System.out.println(classroom);
	}

}
