package com.tka.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
	   
	
	private static final String String = null;
	public static void loadDriver(String driverName) throws ClassNotFoundException
	{
		Class.forName(driverName);
		
	}
	//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/185db","root","1234");

	public static   Connection createConnection(String url,String username,String pass ) throws SQLException
	{
    	Connection con=DriverManager.getConnection(url,username,pass);
		return con;

		
	}
	//Statement stm=con.createStatement();
	  /*public static Statement createStatement(String stm)
	  {
	     //createCo.createStatement();
		  createConnection(url, username, pass).createStatement();
	  }*/
	   public static Statement createStatement(Connection con) throws SQLException
	   {
		   return con.createStatement();
	   }
	   // ResultSet rs=stm.executeQuery(sql);
	   public static ResultSet resultset(Statement stm) throws SQLException
	   {
		   return stm.executeQuery("select * from classroom");
		   
	   }

}
