package com.tka.service;

import java.util.ArrayList;

import com.tka.dao.ClassroomDao;
import com.tka.entity.Classroom;

public class ClassroomServices {
	public ArrayList<Classroom>getAllClassroomsDetails(){
		 ArrayList<Classroom>list= ClassroomDao.fetchAllClassrooms();
		
		return list;
		
	}
	public static Classroom getsingleClassroomsDetailperID(int clsId){
	//ArrayList<Classroom>getAllClassroomsDetails(){
			Classroom classroomNew=new Classroom();	
			 ArrayList<Classroom>listcls= ClassroomDao.fetchAllClassrooms();
			 for(Classroom classroom:listcls)
			 {
				if(clsId==classroom.getClsId())
				{ 
				classroomNew.setClsId(classroom.getClsId());
				classroomNew.setClsName(classroom.getClsName());
				}
			}
			 if(classroomNew.getClsName()==null)
			 {
				 classroomNew.setClsName("not exist please  enter the  classroom");
			 }
			 return classroomNew;
					 
			 }
	
		
	
	Classroom loadsingleClassroomsDetailperName(String clsName){//not used get because wqe have getter and setter method little bit tile we confused
		return null;
		
	}
	Classroom getsingleClassroomsDetailperSize(int size){
		
		return null;
		
	}
	Classroom getsingleClassroomsDetailperFloor(int florNumber){
		
		return null;
		
	}
	Classroom getsingleClassroomsDetailAboveCapacity(int capacity){
		
		return null;
		
	}
	Classroom deleteClassroomsDetailAboveCapacity(int capacity){
		
		return null;
		
	}
	Classroom UpdateClassroomsDetailAboveCapacity(int clsId,String clsName){
		
		return null;
		
	}
	
	
	
	

}
