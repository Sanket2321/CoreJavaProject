package com.tka.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.tka.entity.Classroom;
import com.tka.util.DatabaseUtil;

public class ClassroomDao {
            public static ArrayList<Classroom> fetchAllClassrooms(){
            	
            	ArrayList<Classroom> listcls=new ArrayList<>();
            try
            { 
            	//Class.forName("com.mysql.cj.jdbc.Driver");
            	DatabaseUtil.loadDriver("com.mysql.cj.jdbc.Driver");	
            	Connection con=DatabaseUtil.createConnection("jdbc:mysql://localhost:3306/185db", "root", "1234");
            	//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/185db","root","1234");
            	
            	//Statement stm=con.createStatement();
            	Statement stm=DatabaseUtil.createStatement(con);
            	String sql="select * from classroom";
            	System.out.println("Executing query: " + sql);
            	System.out.println("1");
            	ResultSet rs=DatabaseUtil.resultset(stm);
            	   //ResultSet rs=stm.executeQuery(sql);
            	while(rs.next())
            	{
            		Classroom classroom=new Classroom();
            		int id=rs.getInt(1);
            	    String classname= rs.getString(2);
            	    classroom.setClsId(id);
            	    classroom.setClsName(classname);
            	    listcls.add(classroom);
            	    //classroom.toString();
            	    
            	    
            	}
            	
            	System.out.println("Query executed successfully.");
            }catch(Exception e)
            {
            	e.printStackTrace();
            }
			return listcls;
            	
            }
}
