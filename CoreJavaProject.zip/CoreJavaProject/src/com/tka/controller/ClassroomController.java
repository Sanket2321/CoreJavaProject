package com.tka.controller;

import java.util.ArrayList;

import com.tka.entity.Classroom;
import com.tka.service.ClassroomServices;

public class ClassroomController {
	public static ArrayList<Classroom> fetchAllClassrooms()
	{ 
		
		ClassroomServices classroomService=new ClassroomServices();
		return classroomService.getAllClassroomsDetails();
	}
	public static Classroom getsingleClassroomsDetailperID(int clsId)
	{
		ClassroomServices classroomService=new ClassroomServices();
		return ClassroomServices.getsingleClassroomsDetailperID(clsId);
	}
	}


